package emsapp.dungvmnguyen.dhbk.emsapp.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import emsapp.dungvmnguyen.dhbk.emsapp.R;

public class ChangePasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_changepassword);
    }
}
