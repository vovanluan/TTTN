package emsapp.dungvmnguyen.dhbk.emsapp.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import emsapp.dungvmnguyen.dhbk.emsapp.R;

/**
 * Created by truong d on 10/14/2017.
 */

public class HistoryRowActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_item);
    }

}
